OBSERVATION LOG

Manual Task Observed:

Frequency:
(Daily / Weekly / Per Deal)

================================

CURRENT METHOD
(How it is done today)

--------------------------------

FRICTION / INEFFICIENCIES
- 
- 

--------------------------------

POTENTIAL IMPROVEMENT (NO SOLUTIONS YET)
-
