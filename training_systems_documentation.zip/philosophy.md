PERSONAL OPERATING PHILOSOPHY

Role:
Trainee / Documentation Lead / Systems Analyst

================================

CORE PRINCIPLES
- Learn before changing
- Respect existing workflows
- Document for continuity
- Accuracy over speed

--------------------------------

HOW I WORK
- Observe first
- Ask clarifying questions
- Document daily
- Avoid assumptions

--------------------------------

SUCCESS CRITERIA
- Processes are clearly documented
- Knowledge is transferable
- Reduced dependency on individuals
