DAILY TRAINING LOG

Date:1-19-26 
Location:GS Finance
Trainer(s):
Grace Simpson
================================

PRIMARY FOCUS TODAY
(What I was primarily exposed to today)

--------------------------------

PROCESSES OBSERVED
- 
- 
- 

--------------------------------

PEOPLE & ROLES
- Name – Role
- Name – Role

--------------------------------

TOOLS / SYSTEMS USED
- 
- 

--------------------------------

STEP-BY-STEP NOTES
1.
2.
3.
4.

--------------------------------

DECISIONS MADE TODAY
- What decision:
- Who made it:
- Reason given:

--------------------------------

QUESTIONS / UNCLEAR ITEMS
- 
- 

--------------------------------

CONTINUITY NOTES
(What someone replacing me would need to know)
-
