# DECISION RECORD
**Date:** 1-21-26
**Decision:** Capitalization Threshold Logic

================================
**CONTEXT**
We don't put everything in the database. We need a filter.

--------------------------------
**LOGIC / ALGORITHM**
IF (Cost >= $5,000) AND (Useful Life > 1 Year):
    [cite_start]THEN -> Capitalize (Track in RAMI) [cite: 771]
ELSE IF (Sponsor Requirement exists):
    [cite_start]THEN -> Capitalize regardless of cost [cite: 789]
ELSE:
    THEN -> Expense as "Supplies" (Don't track)

--------------------------------
**RISKS / EDGE CASES**
- "Walkables" (Laptops/Tablets under $5k):
    - *Observation:* We currently track these manually in a spreadsheet because they are high theft risk, even if not "Capitalized".
    - *Future Feature:* Create "Low Value Asset" tracking in new app.