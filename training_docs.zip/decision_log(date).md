DECISION RECORD

Date:

Decision:
(What was decided)

================================

CONTEXT
(What led up to this)

--------------------------------

OPTIONS CONSIDERED
- Option A:
- Option B:
- Option C:

--------------------------------

RATIONALE
(Why this option was chosen)

--------------------------------

RISKS / CONCERNS NOTED
-
