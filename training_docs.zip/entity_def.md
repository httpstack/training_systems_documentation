# ENTITY DEFINITION: [Entity Name] (e.g., Property)

================================
**ATTRIBUTES (Columns)**
- **ID:** (UUID or Legacy ID format)
- **Name/Title:**
- **Status:** [Enum: Active, Inactive, Pending]
- **Dates:** [Created_At, Updated_At, Expiry_Date]

--------------------------------
**RELATIONSHIPS (Foreign Keys)**
- Belongs to: (e.g., Landlord)
- Has many: (e.g., Tenants)

--------------------------------
**VALIDATION RULES**
- (e.g., "End Date must be after Start Date")
- (e.g., "Zip code must be 5 digits")