DAILY PLAYBOOK

MORNING
☐ Review yesterday’s notes
☐ Identify focus for the day

--------------------------------

DURING THE DAY
☐ Observe workflows
☐ Ask “why” when unclear
☐ Capture steps immediately

--------------------------------

END OF DAY
☐ Complete Daily Log
☐ Update process docs
☐ Record unanswered questions

================================

FIRST WEEK CHECKLIST
☐ Learn team roles
☐ Identify all tools & systems
☐ Observe full transaction lifecycle
☐ Document 3–5 processes
☐ Build glossary of terms
