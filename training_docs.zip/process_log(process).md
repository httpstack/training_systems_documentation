PROCESS DOCUMENTATION

Process Name:

Purpose:
(Why this process exists)

Trigger:
(What starts this process)

================================

INPUTS
- 
- 

--------------------------------

PROCESS STEPS
1.
2.
3.
4.
5.

--------------------------------

OUTPUTS
- 

--------------------------------

EXCEPTIONS / VARIATIONS
- 

--------------------------------

WHY THIS PROCESS IS DONE THIS WAY
-
